# BepInEx
Unified BepInEx all-in-one odding pack - plugin framework, detour library